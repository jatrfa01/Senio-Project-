'use strict';

describe('loginApp.login module', function() {

  beforeEach(module('loginApp.login'));

  describe('login controller', function(){

    it('should ....', inject(function($controller) {
      //spec body
      var loginCtrl = $controller('loginCtrl');
      expect(loginCtrl).toBeDefined();
    }));

  });
});