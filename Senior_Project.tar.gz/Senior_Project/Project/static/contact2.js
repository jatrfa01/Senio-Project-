function showelement()
{                 
   var div = document.createElement('div');
   div.setAttribute('id', 'twcCookieDiv');
   div.innerHTML = '<div class="twcCookieDivText">'+ cookietext +'</div><div class="twcCookieDivLinks"><a href="cookie-policy" class="m-btn mini rnd">'+ viewcookie +'</a ><a href="javascript:void(0);" class="m-btn blue mini rnd" onclick="resetcookievalue();">' + cookieaccept + '</a></div>';
   document.body.appendChild(div);
}                     
function getCookieHome(c_name)
{
var c_value = document.cookie;
var c_start = c_value.indexOf(" " + c_name + "=");
if (c_start == -1)
  {
  c_start = c_value.indexOf(c_name + "=");
  }
if (c_start == -1)
  {
  c_value = null;
  }
else
  {
  c_start = c_value.indexOf("=", c_start) + 1;
  var c_end = c_value.indexOf(";", c_start);
  if (c_end == -1)
  {
c_end = c_value.length;
}
c_value = unescape(c_value.substring(c_start,c_end));
}
return c_value; 
}

function setCookieHome(c_name,value,exdays)
{
var exdate=new Date();
exdate.setDate(exdate.getDate() + exdays);
var c_value=escape(value) + ((exdays==null) ? "" : "; expires="+exdate.toUTCString());
document.cookie=c_name + "=" + c_value;
}

function checkCookieHome()
{
var username=getCookieHome("username");
  if (username!=null && username!="")
  {
     if(username == "2")
     {
         $("#twcCookieDiv").hide();
     }
     else{
         showelement();
     }    
  }
else
  {
    showelement();
    setCookieHome("username","1",365); 
    /*if (username == "2")
    {
      document.body.removeChild(document.getElementById('twcCookieDiv'));
    } */
  }
}
function resetcookievalue()
{
   $("#twcCookieDiv").hide();
   setCookieHome("username","2",365);
}

$(window).load(function () { checkCookieHome(); });



/*var twc_CookieLive = true;
var twc_CookieName = 'TWCCookiesAllowed';
var twc_CookieShowMask = false;
function twcCookieCheck() {
    var cookies = document.cookie.split(';');
    for (var i = 0; i < cookies.length; i++) 
    {
        var nme = cookies[i].substr(0, cookies[i].indexOf("="));
        nme = nme.replace(/^\s+|\s+$/g, "");
        var val = cookies[i].substr(cookies[i].indexOf("=") + 1);
        if ((nme == twc_CookieName) && (unescape(val) == 'true')) return;
    }
    
    var debugMode = false;
    var regexS = "[\\?&]twc_CookieDebug=([^&#]*)";
    var regex = new RegExp(regexS);
    var results = regex.exec(window.location.search);
    if (results != null)
    {
        if (decodeURIComponent(results[1].replace(/\+/g, " ")) == 'true') debugMode = true;
    }

    if ((!twc_CookieLive) && (!debugMode)) return;

    if (twc_CookieShowMask) {
        var mask = document.createElement('div');
        mask.setAttribute('id', 'twcCookieMask');
        document.body.appendChild(mask);
    }

    var div = document.createElement('div');
    div.setAttribute('id', 'twcCookieDiv');
    div.innerHTML = '<div class="twcCookieDivText">We use cookies to give you the best possible online experience. If you continue, we will assume you are happy to receive all cookies from our website.</div><div class="twcCookieDivLinks"><a href="cookie-policy.html" class="m-btn mini rnd">View Cookie Policy</a ><a href="javascript:void(0);" class="m-btn blue mini rnd" onclick="twcCookieAgree()">I AGREE to the use of cookies</a></div>';
    document.body.appendChild(div);
    //$("#twcCookieDiv").effect('bounce', {}, 500);
}
function twcCookieAgree() {
    var exdate = new Date();
    exdate.setDate(exdate.getDate() + 365);
    document.cookie = twc_CookieName + '=true;expires=' + exdate.toUTCString() + ';path=/';
    document.body.removeChild(document.getElementById('twcCookieDiv'));
    if (document.getElementById('twcCookieMask')) document.body.removeChild(document.getElementById('twcCookieMask'));
    return false;
} */

